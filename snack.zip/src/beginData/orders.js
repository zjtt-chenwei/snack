let orders = [
  {
    id: 1,  // 订单编号
    saleId: 2, // 卖家id
    buyId: 3, // 卖家id
    salePhone: '18100170000', // 卖家电话号码
    buyPhone: '88888888888', // 买家电话号码
    shopId: 2, // 商品id
    shopName: '香肠', // 商品名称
    shopNum: 10, // 订单商品数量
    shopPrice: 2.00, // 订单商品价格
    status: 0, // 订单状态  0已关闭  1交易中  2已付款 3已结束
    createTime: '2020-05-09 19:54' //订单创建时间
  }
]
export default orders;